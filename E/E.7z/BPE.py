import string

def tokenize(input):
    input = input.lower()
    translator = str.maketrans('', '', string.punctuation)
    no_punct = input.translate(translator)
    tokens = []
    tokens.append("<w>")
    for c in no_punct:
        if c == " ":
            tokens.append("<w>")
        else:
            tokens.append(c)
    tokens.append("<w>")
    return tokens

def count_bigrams(tokens):
    bigram_counts = {}
    for i in range(len(tokens)-1):
        bigram = (tokens[i], tokens[i + 1])
        bigram_counts[bigram] = bigram_counts.get(bigram, 0) + 1
    return bigram_counts

def find_most_frequent_bigram(bigram_counts):
    return max(bigram_counts, key=bigram_counts.get)

def replace_bigram(tokens, bigram, subword):
    # Replace occurrences of the bigram with the subword in the list of tokens
    new_tokens = []
    i = 0
    while i < len(tokens):
        if i < len(tokens) - 1 and (tokens[i], tokens[i + 1]) == bigram:
            new_tokens.append(subword)
            i += 2
        else:
            new_tokens.append(tokens[i])
            i += 1
    return new_tokens

def merge_dictionaries(dict1, dict2):
    result_dict = dict1.copy()

    for key, value in dict2.items():
        if key in result_dict:
            result_dict[key] = max(result_dict[key], value)
        else:
            result_dict[key] = value

    return result_dict


if __name__ == "__main__":
    sentence=input("Podaj zdanie wejsciowe: ")
    # sentence = "Hurry on Harry, hurry on!"
    v = int(input("Podaj ile podsłów conajmniej chcesz otrzymać: "))
    # v=10
    bigrams=[]
    tokens=tokenize(sentence)
    tokens_backup = tokens
    vocab = set(tokens)
    
    while len(vocab) <= v:
        bigram_counts = count_bigrams(tokens)
        # print("BC: ",bigram_counts)
        max_bigram = find_most_frequent_bigram(bigram_counts)
        marged_bigram = "".join(max_bigram)
        # print("BG MAX:",marged_bigram)
        vocab.add(marged_bigram)
        tokens = replace_bigram(tokens, max_bigram, marged_bigram)
        # print("TOKENS: ",tokens)

    subword_counts_1 = {subword: tokens_backup.count(subword) for subword in vocab}
    # print(subword_counts_1)
    subword_counts_2 = {subword: tokens.count(subword) for subword in vocab}
    # print(subword_counts_2)
    subword_counts = merge_dictionaries(subword_counts_1, subword_counts_2)


    voc_quan_sorted = dict(sorted(subword_counts.items(), key=lambda item: item[1], reverse=True))
    print(voc_quan_sorted)