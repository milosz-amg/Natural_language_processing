# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# W FOLDERZE Z PLIKIEM MAXMATCH.PY NALEZY UMIESCIC SLOWNIK, JEST ZA DUZY BY PRZESYLAC GO PRZEZ TEAMSA   #
# NAZWE PLIKU ZDEFINIOWANO W ZMIENNEJ GLOBALNEJ PONIŻEJ                                                 #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

POLIMORF_PATH= "PoliMorf-0.6.7.tab"

def load_polimorf_dict(file_path):
    with open(file_path, encoding="utf-8") as file:
        entries = [line.strip().split('\t')[0] for line in file]
        return set(entries)

def max_match(sentence, dictionary):
    words = []
    i = 0
    while i < len(sentence):
        found = False
        max_match_length = 0
        
        for j in range(len(sentence), i, -1):
            if sentence[i:j] in dictionary and j - i > max_match_length:
                words.append(sentence[i:j])
                i = j
                max_match_length = j - i
                found = True
                break
        
        if not found:
            words.append(sentence[i])
            i += 1

    return words

if __name__ == "__main__":
    print("Ładowanie słownika...")
    polimorf_dict = load_polimorf_dict(POLIMORF_PATH)
    test_sentence = "dlaczegoniemożnakupićsłoniawPolsce"

    print("Zdanie testowe: dlaczegoniemożnakupićsłoniawPolsce")
    result = max_match(test_sentence, polimorf_dict)
    print("Wynik segmentacji:", " ".join(result))

    while True:
        input_sentence = input("Wprowadź swoje zdanie: ")
        result = max_match(input_sentence, polimorf_dict)
        print("Wynik segmentacji:", " ".join(result))
