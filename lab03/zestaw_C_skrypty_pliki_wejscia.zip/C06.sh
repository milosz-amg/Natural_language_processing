#!/bin/bash
tr -c 'A-Za-z0-9[:space:][:punct:]' 'X'
# ./C06.sh < pl.in > pl.out